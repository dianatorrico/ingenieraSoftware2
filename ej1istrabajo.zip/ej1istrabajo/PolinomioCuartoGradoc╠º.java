/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author dianatorrico
 */
public class PolinomioCuartoGrado {
    private double a;
    private double b;
    private double c;
    private double d;
    private double e;

    //constructor
    public PolinomioCuartoGrado(double a, double b, double c, double d, double e) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
    }

    //métodos básicos
    public double getA() {
        return a;
    }
    
    public void setA(double a) {
        this.a = a;
    }
    public double getB() {
        return b;
    }
    public void setB(double b) {
        this.b = b;
    }
    public double getC() {
        return c;
    }
    public void setC(double c) {
        this.c = c;
    }
    public double getD() {
        return d;
    }
    public void setD(double d) {
        this.d = d;
    }
    public double getE() {
        return e;
    }
    public void setE(double e) {
        this.e = e;
    }

    @Override
    public String toString() {
        return "PolinomioCuartoGrado [a=" + a + ", b=" + b + ", c=" + c + ", d=" + d + ", e=" + e + "]";
    }

    
    

}