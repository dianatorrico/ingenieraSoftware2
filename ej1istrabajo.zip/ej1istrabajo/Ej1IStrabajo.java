/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ej1istrabajo;

/**
 *
 * @author dianatorrico
 */
public class Ej1IStrabajo {

    public static void main(String[] args) {
        //prueba polinomio 1 grado
       PolinomioPrimerGrado p1 = new PolinomioPrimerGrado(4,2);
       System.out.print(p1.calcularValor(2));
       System.out.print(" ");

       PolinomioPrimerGrado p2 = new PolinomioPrimerGrado(2,4);
       System.out.print(p2.calcularValor(2));
       System.out.print(" ");

       //prueba polinomio 2 grado 
       PolinomioSegundoGrado p12 = new PolinomioSegundoGrado(2,4,2);
       System.out.print(p12.calcularValor(2));
       System.out.print(" ");

       PolinomioSegundoGrado p22 = new PolinomioSegundoGrado(2,4,6);
       System.out.print(p22.calcularValor(2));
       System.out.print(" ");

       //prueba polinomio 3 grado 
       PolinomioTercerGrado p32 = new PolinomioTercerGrado(4,1,3,2);
       System.out.print(p32.calcularValor(2));
       System.out.print(" ");

       PolinomioTercerGrado p31 = new PolinomioTercerGrado(2,4,6,7);
       System.out.print(p31.calcularValor(2));
       System.out.print(" ");

       //prueba producto polinomio 
       ProductoPolinomio2Grado p4 = new ProductoPolinomio2Grado(p12,p22);
       System.out.print(p4.productoPolinomios);
       

    }
}
