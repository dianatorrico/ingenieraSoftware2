/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ej1istrabajo;

/**
 *
 * @author dianatorrico
 */
public class PolinomioPrimerGrado {
    
    private double b;
    private double a;

    //constructor 
    public PolinomioPrimerGrado(double a, double b) {
        this.b = b;
        this.a= a;
    }
    
    
    //métodos básicos
    public double getA() {
        return a;
    }

    public void setA(double a) {
        this.a = a;
    }

    public double getB() {
        return b;
    }

    public void setB(double b) {
        this.b = b;
    }
    
    //calcular valor del polinomio
    public double calcularValor(double x) {
        double resultado = (this.getA()*x) + this.getB();
        return resultado; 
    }

    @Override
    public String toString() {
        return "PolinomioPrimerGrado{" + "a=" + a + ", b=" + b + '}';
    }
    

}
